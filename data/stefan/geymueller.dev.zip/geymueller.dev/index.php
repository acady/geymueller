<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <!--
    Created by Artisteer v3.1.0.55575
    Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"
    -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <META HTTP-EQUIV="refresh" CONTENT="0;url=/geonames/">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <title>geymueller.dev</title>
<body style="background: #C7CDD2;">
<!--Du bist auf der neuen Startseite von faircheck bei der CityCom. Gleich geht es weiter.... <br>-->
</body>
</html>
<!--
<?php
	echo ("<br>");
	echo getcwd();
	echo ("<br>");
	echo $_SERVER['DOCUMENT_ROOT']; 
	echo ("<br>");
	echo ("-----------");
	phpinfo();
?>
-->
